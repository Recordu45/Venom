# venom

<h2 align="centre"> 𝙕𝙖𝙞𝙙 𝙑𝙤𝙞𝙘𝙚 𝙋𝙡𝙖𝙮𝙚𝙧🔥</h2>

### ᴢᴀɪᴅ ᴠᴄ ᴘʟᴀʏᴇʀ ɪꜱ ᴀ ᴛᴇʟᴇɢʀᴀᴍ ᴘʀᴏᴊᴇᴄᴛ ʙᴀꜱᴇᴅ ᴏɴ ᴘʏʀᴏɢʀᴀᴍ ꜰᴏʀ ᴘʟᴀʏ ᴍᴜꜱɪᴄꜱ ɪɴ ᴠᴄ ᴄʜᴀᴛꜱ...

<p align="center"><a href="https://t.me/Superior_Bots"><img src="https://telegra.ph/file/c4e036012053c3eb85e80.jpg" width="300"></a></p>
<p align="center">
    <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>

## 🅡🅔🅟🅞 🅢🅣🅐🅣🅢
![github card](https://github-readme-stats.vercel.app/api/pin/?username=ITZ-DAAKU&repo=Daaku-Vc-Player&theme=dark)

<h3>ʀᴇQᴜɪʀᴇᴍᴇɴᴛꜱ 📝</h3>

- FFmpeg
- NodeJS [nodesource.com](https://nodesource.com/)
- Python 3.8+ or 3.7
- [PyTgCallss](https://github.com/ITZ-DAAKU/calls)

#

<p align="center">Deploy with Cloner Bot</p>

<p align="center"><a href="https://github.com/ITZ-DAAKU/Daaku-Vc-Player/tree/clone"> <img src="https://img.shields.io/badge/Cloner%20Branch-blue?style=for-the-badge&logo=github" width="220" height="38.45"/></a></p>


#

<p align="center">𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐞 𝐒𝐭𝐫𝐢𝐧𝐠 𝐒𝐞𝐬𝐬𝐢𝐨𝐧</p>

<p align="center"><a href="https://replit.com/@Itz-daaku/Generator"> <img src="https://img.shields.io/badge/String%20Session-black?style=for-the-badge&logo=replit" width="220" height="38.45"/></a></p>


#

<p align="center">𝐇𝐞𝐫𝐨𝐤𝐮 𝐃𝐞𝐩𝐥𝐨𝐲𝐦𝐞𝐧𝐭 𝐓𝐮𝐭𝐨𝐫𝐢𝐚𝐥</p>

<p align="center"><a href="https://youtu.be/nQAyresJTC0"> <img src="https://img.shields.io/badge/Youtube%20Deploy-red?style=for-the-badge&logo=youtube" width="220" height="38.45"/></a></p>

## ᴄᴏᴍᴍᴀɴᴅꜱ 

[CLICK HERE](https://t.me/SUPERIOR_BOTS/160)


## ꜰᴇᴀᴛᴜʀᴇꜱ ᴡɪᴛʜ ᴀɪ 🔥️

> Here is the given all Features.. !

<details>
    <summary><b> Click here to expand » </b></summary>

- **ᴘʟᴀʏ ᴍᴜꜱɪᴄ ɪɴ ᴛᴇʟᴇɢʀᴀᴍ ɢʀᴏᴜᴘ ᴠᴏɪᴄᴇ ᴄʜᴀᴛꜱ!** (ꜱᴜᴘᴘᴏʀᴛꜱ ᴍᴜʟᴛɪᴘʟᴇ ɢʀᴏᴜᴘꜱ)
- **ꜱᴜᴘᴘᴏʀᴛꜱ Qᴜᴇᴜᴇꜱ!**
- **ᴄᴏɴᴛʀᴏʟ ʙʏ ʙᴜᴛᴛᴏɴꜱ ᴏʀ ᴄᴏᴍᴍᴀɴᴅꜱ**
- **ꜱᴇᴀʀᴄʜ ꜰᴏʀ ʏᴏᴜᴛᴜʙᴇ ᴠɪᴅᴇᴏꜱ ɪɴʟɪɴᴇ!**
- **ᴅᴏᴡɴʟᴏᴀᴅ ʏᴛ ꜱᴏɴɢꜱ ʙʏ ɪᴛ'ꜱ ɴᴀᴍᴇ!**
- **ᴅᴏᴡɴʟᴏᴀᴅ ʏᴛ ᴠɪᴅᴇᴏꜱ ʙʏ ɪᴛ'ꜱ ɴᴀᴍᴇ!**
- **ɢᴇᴛ ʟʏʀɪᴄꜱ ᴏꜰ ʏᴏᴜʀ ꜱᴏɴɢ!**
- **ᴊᴏɪɴ & ʟᴇᴀᴠᴇ ꜱᴛʀᴇᴀᴍᴇʀ ᴀᴄᴄᴏᴜɴᴛ ᴜꜱɪɴɢ ᴀ ᴄᴏᴍᴍᴀɴᴅ**
- **ᴄᴏᴏʟ ꜱᴛᴀʀᴛꜱ ᴘʟᴜɴɢɪɴꜱ**
- **Spam**
- **Reply Raid**
- **Love Raid**
- **Voice Raid**
- **Video Raid**
- **Skip, Pause, Resume, Stop feature**
- **YouTube/Local/Live/m3u8 ʟɪɴᴋ stream support**
- **Control With Button support**
- **Volume Control**
- **Userbot Auto Join**
- **Multi Assistant**
</details>

## 🔎 ꜱᴜᴘᴘᴏʀᴛ ɪɴʟɪɴᴇ ꜱᴇᴀʀᴄʜ

## ᴅᴇᴘʟᴏʏ

ᴛᴏ ʙᴇ ꜱᴀꜰᴇ ꜰᴏʀᴋ ᴛʜɪꜱ ʀᴇᴘᴏ ᴀɴᴅ ᴛʜᴇɴ ᴘʀᴇꜱꜱ ᴅᴇᴘʟᴏʏ ʙᴜᴛᴛᴏɴ ꜰʀᴏᴍ ᴛʜᴇ ꜰᴏʀᴋᴇᴅ ʀᴇᴘᴏ 

[ꜰᴏʀᴋ ᴅᴇᴘʟᴏʏ ɪꜱ ʜɪɢʜʟʏ ʀᴇᴄᴏᴍᴍᴇɴᴅᴇᴅ](https://telegra.ph/file/5bcf79f948ca06030640c.mp4)

<p align="center"><a href="https://my.scalingo.com/deploy?template=https://github.com/ITZ-DAAKU/Daaku-Vc-Player"> <img src="https://cdn.scalingo.com/deploy/button.svg" width="220" height="38.45"/></a></p>

> Click on buttons below to expand and  detailed explanation process. !


<details>
    <summary><b> Detailed Heroku Depoyment Process » </b></summary>

<img src="https://telegra.ph/file/97e6de197eba98d2caba5.jpg" align="right" width="350" height="700"/>

### 🚀 Deploy Process
- Click on the deploy button above and login to your [heroku account](https://heroku.com/login) .
- Fill your values there.
- If you don't know how to get config vars : [Please refer here](https://github.com/ITZ-DAAKU/Daaku-Vc-Player/blob/main/sample.env)
- Make sure you fill correct values.
- Click on **Deploy** button.
- Please wait till the app gets deployed on heroku. Deploying can take upto **2-3 mins**..
- When your app is successfully deployed, click on **Manage App** button.


### 🚀 Booting Process
- Search for **Resources** Tab inside your app. ( Check Image for more details)
- Click on the **Pencil Icon** under resources section.
- Turn **on** the **switch** present there near pencil icon.
- Congrats your Music Bot is now **Booting**.


### 🚀 Checking Logs
- After Turning on your booting .
- Click on the **More Button** present at top right corner .
- Click on the **View Logs** button from the drop down menu.
- You check your logs there!
- Click on save button there at bottom to save your logs and forward it to us on [@Bot_Support](https://t.me/Superior_Support) if you face any problem

</details>


## 🚀 Okteto Deployment

<h4>Click the button below to deploy on Okteto!</h4>
<p align="center"><a href="https://cloud.okteto.com/deploy?repository=https://github.com/ITZ-DAAKU/Daaku-Vc-Player"><img src="https://img.shields.io/badge/Deploy%20To%20Okteto-informational?style=for-the-badge&logo=Okteto" width="200""/></a>

## Workflows hosting

<h4>Click the button below to import this code. How to host? Simply import this code then fill your vars in config.py then go to Actions and check build logs!</h4>
<p align="center"><a href="https://github.com/new/import"><img src="https://img.shields.io/badge/Workflow%20Deploy-black?style=for-the-badge&logo=github" width="200""/></a>


## ᴅᴇᴘʟᴏʏ ᴏɴ ʀᴀɪʟᴡᴀʏ 🚄
ꜰᴏʀ ᴅᴇᴘʟᴏʏ ᴏɴ ʀᴀɪʟᴡᴀʏ ᴍᴀᴋᴇ [Necessary Variables Here](https://github.com/ITZ-DAAKU/Daaku-Vc-Player), ᴜ ʜᴀᴠᴇ ᴛᴏ ꜰɪʟʟ.

<p align="center"><a href="https://railway.app/new/template?template=https://github.com/ITZ-DAAKU/Music-Deploy&envs=SESSION_NAME,BOT_TOKEN,GROUP_SUPPORT,UPDATES_CHANNEL,API_ID,API_HASH,SUDO_USERS,DURATION_LIMIT"> <img src="https://img.shields.io/badge/Deploy%20To%20Railway-black?style=for-the-badge&logo=railway" width="220" height="38.45"/></a></p>


<h2 align="center">
   Install Locally Or On A VPS
</h2>


```console
Daaku@Windows~ $ git clone https://github.com/ITZ-DAAKU/Daaku-Vc-Player
Daaku@Windows~ $ cd Daaku-Vc-Player
Daaku@Windows~ $ bash setup
Daaku@Windows~ $ cp sample.env .env
```

<h3 align="center">
    Edit <b>.env</b> with your own values and Run Bot
</h3>

```console
Daaku@Windows~ $ screen
Daaku@Windows~ $ python3 main.py
```

### ꜱᴘᴇᴄɪᴀʟ ᴄʀᴇᴀᴅɪᴛꜱ 💖
- Callsmusic
- Veez
- PyroGram
-xyz ⚡

#

<p align="center">𝐒𝐮𝐩𝐩𝐨𝐫𝐭 / 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 ----> </p>

<p align="center"><a href="https://t.me/TheSupportChat"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐒𝐮𝐩𝐩𝐨𝐫𝐭-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>
<p align="center"><a href="https://t.me/TheUpdatesChannel"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐔𝐩𝐝𝐚𝐭𝐞𝐬-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>

#
